function s(num, val) {
    amount = num * 1; 
    sum = (!num ? 0 : num) * val;  
    
    if (isNaN(amount)) { 
    
    alert(
    "' " + num + " ' is not a valid input. "
    + "BE LIKE OBAMA. GIVE ME CHAAAANGE"
    );
    
    return 0;
    }
    else
    return sum; 
    }
    
    function money(form) {
    qtr = s(form.qtr.value, .25);
    dme = s(form.dme.value, .10);
    nck = s(form.nck.value, .05);
    pny = s(form.pny.value, .01);
    var ttl = qtr + dme + nck + pny;

    ttl = "" + ((Math.round(ttl * 100)) / 100);
    
    dec1 = ttl.substring(ttl.length-3, ttl.length-2);
    dec2 = ttl.substring(ttl.length-2, ttl.length-1);
    
    if (dec1 != '.') { 
    if (dec2 == '.') ttl += "0";
    else ttl += ".00";
    }
    form.total.value = "$ " + ttl; 
    }